module.exports={
    clientID: '215622131837-ng6r9tcsolbr4oeejm1l870i3on10fvs.apps.googleusercontent.com',
    clientSecret: 'QPpEGqDMmzO3z7khjD52cMsn'
}