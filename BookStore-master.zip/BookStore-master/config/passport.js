  const GoogleStrategy = require('passport-google-oauth20').Strategy;
  const mongoose = require('mongoose');
  const passport = require('passport');
  const keys = require('./keys');

  const User = mongoose.model('users');

  module.exports = (passport)=>{
    passport.use(new GoogleStrategy({
    clientID: keys.clientID,
    clientSecret: keys.clientSecret,
    callbackURL: '/auth/google/callback',
    proxy: true
  }, (accessToken, refreshToken, profile, done)=>{
      const newUser = new User({
        googleID: profile.id,
        email: profile.emails[0].value,
        fName: profile.name.givenName
      })

      User.findOne({
        googleID: profile.id
      })
      .then(users=>{
        if(users){
          done(null, users)
        }
        else{
          newUser.save()
          .then(users=>{
            done(null, users);
          })
        }
      })
  }))

  passport.serializeUser((user, done) => {
    done(null, user.id);
  });

  passport.deserializeUser((id, done) => {
    User.findById(id).then(user => done(null, user));
  });
}