const express = require('express');
const exphbs = require('express-handlebars');   
const methodOverride = require('method-override');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const session = require('express-session');
const path = require('path');
const passport = require('passport');
const flash = require('connect-flash');
const nodemailer = require('nodemailer');



const app = express();

const db = require('./config/database');
require('./Model/users');
require('./Model/books');
require('./Model/cart');
require('./Model/card');
require('./Model/orders');
require('./config/passport')(passport);

app.get('/auth/google', passport.authenticate('google', {scope: ['profile', 'email']}));

const Book = mongoose.model('books');
const Cart = mongoose.model('cart');
const Card = mongoose.model('cards');
const Order = mongoose.model('orders');

app.engine('handlebars', exphbs({defaultLayout: 'main'}));
app.set('view engine', 'handlebars');

app.use(flash());

app.use(session({
    secret: 'secret',
    resave: true,
    saveUninitialized: true,
  }))

  
app.use(passport.initialize());
app.use(passport.session());

app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json());

app.use(express.static(path.join(__dirname + 'public')));


//method-override middleware
app.use(methodOverride('_method'));

app.use((req, res, next)=>{
    res.locals.user=req.user||null; 
    next();
})

let transporter;

mongoose.Promise = global.Promise;

mongoose.connect(db.mongoURI, {
    useNewUrlParser: true
})
.then(()=>console.log('MongoDB Connected'))
.catch(err=>console.log(err));

app.get('/', (req, res) =>{
    res.render('homepage');
})

app.get('/cartadd/:id', (req, res)=>{
  Book.findOne({_id:req.params.id})
  .then(book=>{
    const newItem = new Cart({
      bookTitle: book.bookTitle,
      bookAuthor: book.author,
      user: req.user.googleId,
      cost: book.price
    })

    newItem.save()
    .then(items=>{
      
    })
  })
})

app.get('/loggedIn', (req, res)=>{
    let item, ver;
    Card.find({user: req.user.id})
    .then(cards=>{
      ver=cards==null;
      Book.find({
      })
      .then(books=>{
        res.render('loggedIn', {
          title: req.user.fName,
          items: books,
          length: cards.length==0
        });
      })
    })
    if(ver)
      {
      Book.find({
      })
      .then(books=>{
        res.render('loggedIn', {
          title: req.user.fName,
          items: books,
          length: cards.length==0
        });
      });
      }
})

app.get('/credit', (req, res)=>{
      res.render('cardpay')
})

app.get('/shoppingcart', (req, res)=>{
  Cart.find({user:req.user.id})
  .then(carts=>{
    res.render('shoppingcart', {
      items: carts
    })
  })
})



app.get('/profile', (req, res)=>{
  Order.find({user:req.user.id})
  .then(orders=>{
    let ord = orders
    Card.findOne({user:req.user.id})
    .then(cards=>{
      let card = cards
      res.render('profile',{
      ord: ord,
      card: card,})
    })
  })
})

app.get('/addCart/:id', (req, res)=>{
  Book.findOne({_id:req.params.id})
  .then(book=>{
     const newCartItem = new Cart({
      bookTitle: book.bookTitle,
      bookAuthor: book.bookAuthor,
      user: req.user.id,
      cost: book.price
    })
    newCartItem.save()
    .then(cart=>{
      Cart.find({user:req.user.id})
      .then(carts=>{
        res.render('shoppingcart', {
          items: carts
        })
      })
    })
  })

})



app.get('/myOrders', (req, res)=>{
  let totCost = 0;
  Order.find({user:req.user.id})
  .then(orders=>{
    for(i=0;i<orders.length;i++){
     totCost = totCost + parseInt(orders[i].cost);
    }
    Card.findOne({user:req.user.id})
    .then(cards=>{
      let l = cards==null;
      res.render('myOrders', {
        orders: orders,
        tot: totCost,
        cardsBroke: l,
        cards: cards
    })
 
    })
  })
})

app.get('/delOrder/:id',(req, res)=>{
  Order.deleteOne({_id:req.params.id})
  .then(()=>{
    res.redirect('/myOrders');
  })
})

app.get('/confOrder', (req, res)=>{
  res.send('Your Order has been confirmed, we have sent an email for the same!');
  console.log(req.user.email);
  let tot = 0;
  Order.find({user:req.user.id})
  .then(orders=>{
    for(i=0;i<orders.length;i++){
     tot = tot + parseInt(orders[i].cost);
    }
    nodemailer.createTestAccount((err, account) => {
      // create reusable transporter object using the default SMTP transport
      let transporter = nodemailer.createTransport({
          service: 'gmail', // true for 465, false for other ports
          auth: {
            user: 'manutdrmabm@gmail.com',
            pass: 'lcd$creen1bmlpad' // generated ethereal password
          },
          tls:{
            rejectUnauthorized: false
          }
      });
      
      // setup email data with unicode symbols
      let mailOptions = {
          from: '"The BookStore" <manutdrmabm@gmail.com>', // sender address
          to: req.user.email, // list of receivers
          subject: 'Your BookStore1.0 Order', // Subject line
          text: 'Hello world?', // plain text body
          html:  `<p>Hey <b>${req.user.fName}</b>. Your bill is Rs. <b>${tot}</b>. Thank you for shopping! </p>` // html body
      };
  
      // send mail with defined transport object
      transporter.sendMail(mailOptions, (error, info) => {
          if (error) {
              return console.log(error);
          }
          console.log('Message sent: %s', info.messageId);
          // Preview only available when sending through an Ethereal account
          console.log('Preview URL: %s', nodemailer.getTestMessageUrl(info));
  
          // Message sent: <b658f8ca-6296-ccf4-8306-87d57a0b4321@example.com>
          // Preview URL: https://ethereal.email/message/WaQKMgKddxQDoou...
      });
  });
  })

})

app.post('/myOrders/:id', (req, res)=>{
 Cart.findOne({_id:req.params.id})
 .then(cart=>{
   const newOrder = new Order({
     bookTitle: cart.bookTitle,
     bookAuthor: cart.bookAuthor,
     user: req.user.id,
     cost: cart.cost
   })

   newOrder.save()
   .then(cart=>{
     res.redirect('/myOrders')
   })
 })
})

app.get('/auth/google/callback', 
  passport.authenticate('google', { failureRedirect: '/' }),(req, res) => {
    res.redirect('/loggedIn')
  });

app.get('/verify', (req, res) => {
    if(req.user){
      console.log(req.user);
    } else {
      console.log('Not Auth');
    }
  });

app.post('/credit', (req, res)=>{
  const newCard = new Card({
    cardNumber: req.body.cardNum,
    month: req.body.month,
    year: req.body.year,
    user: req.user.id
  })

 newCard.save()
 .then(cards=>{
   res.redirect('/loggedIn');
 })
})

app.get('/myOrderList', (req, res)=>{
  Order.find({user: req.user.id})
  .then(orders=>{
    res.render('myList', {
      items: orders
    })
  })
})

app.get('/logout', (req, res)=>{
    req.logout();
    res.redirect('/');
})

app.get('/cartItemsDel/:id', (req, res)=>{
  Cart.deleteOne({_id:req.params.id})
  .then(()=>{
    res.redirect('/shoppingcart')
  })
})

const port = process.env.PORT || 4040;

app.listen(port, () =>{
  console.log(`Server started on port ${port}`);
});
