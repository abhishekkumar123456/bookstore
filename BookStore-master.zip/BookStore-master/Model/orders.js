const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const OrderSchema =new Schema({
    bookTitle:{
        type: String,          
        required: true
    },
    bookAuthor:{
        type: String,
        required: true
    },
    user:{
        type: String,
        required: true
    },
    Date:{
        type: Date,
        default: Date.now
    },
    cost:{
        type: String,
        required: true
    }
});

mongoose.model('orders', OrderSchema);
