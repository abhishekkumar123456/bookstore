const mongoose=require('mongoose');

const Schema=mongoose.Schema;   //take Schema provided by mongoose

const BookSchema =new Schema({
    id:{
        type: String,          
        required: true
    },
    bookTitle:{
        type: String,
        required: true
    },
    bookAuthor:{
        type: String,
        required: true
    },
    price:{
        type: String, 
        required: true
    }
});

mongoose.model('books', BookSchema);