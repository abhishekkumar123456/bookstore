const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const CardSchema =new Schema({
    cardNumber:{
        type: String,          
        required: true
    },
    month:{
        type: String,
        required: true
    },
    year:{
        type: String,
        required: true
    },
    user:{
        type: String,
        required: true
    }
});

mongoose.model('cards', CardSchema);