const mongoose=require('mongoose');

const Schema=mongoose.Schema;   //take Schema provided by mongoose

const UserSchema =new Schema({
    googleID:{
        type: String,          
        required: true
    },
    email:{
        type: String,
        required: true
    },
    fName:{
        type: String,
        required: true
    }
});

mongoose.model('users', UserSchema);